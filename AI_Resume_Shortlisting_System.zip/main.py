from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Sample Job Description
job_description = """
Looking for a Python developer with knowledge of machine learning, NLP, and data analysis.
"""

# Sample Resumes
resumes = [
    """Python developer with experience in data analysis and machine learning.""" ,
    """Web developer skilled in HTML, CSS, JavaScript.""" ,
    """Data scientist with expertise in Python, NLP, and machine learning."""
]

documents = [job_description] + resumes

vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform(documents)

cosine_sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:])[0]

ranked_resumes = sorted(
    enumerate(cosine_sim),
    key=lambda x: x[1],
    reverse=True
)

print("Resume Ranking:")
for idx, score in ranked_resumes:
    print(f"Resume {idx+1} - Score: {score:.2f}")
