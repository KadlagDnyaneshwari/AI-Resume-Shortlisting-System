# AI-Based Resume Shortlisting System

This project shortlists and ranks resumes based on a given Job Description using NLP techniques.

## Features
- Resume parsing
- Job description parsing
- TF-IDF & cosine similarity based ranking
- Simple, beginner-friendly implementation

## Tech Stack
- Python
- scikit-learn
- nltk

## How to Run
1. Install dependencies:
   pip install -r requirements.txt
2. Run:
   python main.py
